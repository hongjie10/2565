@echo off
rem gtkwave can't load Chinese paths, so copy to ASCII path first
copy /y "%~dp0wave.vcd" "C:\Users\Public\wave.vcd" >nul
start "" "C:\msys64\ucrt64\bin\gtkwave.exe" "C:\Users\Public\wave.vcd"
