#!/usr/bin/env python3
"""golden.py — Python 黄金模型：生成测试向量与期望输出。

与 rtl/exp_lut.v 共用同一张定点 exp 表：weight = round(exp(score - x_max) * 16)，
无符号定点，小数保留 4 位。必须先找 x_max 再算 weight（数值稳定 softmax）。
O = round(ACC/L)，四舍五入远离零（与 RTL 除法器一致）。
输出 stim.hex（输入字节）和 exp.hex（期望输出，8-bit 补码）。
"""
import random


def exp_w(score, x_max):
    """weight = round(exp(score - x_max) * 16)，无符号定点，小数 4 位"""
    d = score - x_max
    if d >= 0:
        return 16
    elif d == -1:
        return 6
    elif d == -2:
        return 2
    elif d == -3:
        return 1
    else:
        return 0


def round_div(a, L):
    """round(a/L)，四舍五入远离零：|a|/L 余数×2>=L 则商+1，再按符号还原"""
    q = abs(a) // L
    r = abs(a) - q * L
    if 2 * r >= L:
        q += 1
    return -q if a < 0 else q


def golden(q, k, v):
    """q: list[4]，k/v: 8x4 -> 返回 O[0..3]（list[4]，8-bit）"""
    # 第一遍：算 8 个 score，找最大值 x_max
    scores = [sum(q[kk] * k[j][kk] for kk in range(4)) for j in range(8)]
    x_max = max(scores)

    # 第二遍：定点 weight，累加 L 和 ACC
    L = 0
    acc = [0, 0, 0, 0]
    for j in range(8):
        w = exp_w(scores[j], x_max)
        L += w
        for kk in range(4):
            acc[kk] += w * v[j][kk]

    return [round_div(acc[kk], L) for kk in range(4)]


def filter_golden(q, k, T=0):
    """D 加分项：返回 (sel_mask, sel_cnt)。weight > T 的 key 被选中，
    sel_mask 的 bit j 对应 key j，与 RTL 的 sel_mask 一致。"""
    scores = [sum(q[kk] * k[j][kk] for kk in range(4)) for j in range(8)]
    x_max = max(scores)
    sel_mask = 0
    sel_cnt = 0
    for j in range(8):
        if exp_w(scores[j], x_max) > T:
            sel_mask |= (1 << j)
            sel_cnt += 1
    return sel_mask, sel_cnt


def causal_golden(q, k, v, q_pos):
    """A 加分项：因果 Mask，屏蔽 j > q_pos 的 future key。返回 O[0..3]。
    先把 future key 的 score 置 -inf（不参与 max），再正常 softmax。"""
    scores = [sum(q[kk] * k[j][kk] for kk in range(4)) for j in range(8)]
    for j in range(q_pos + 1, 8):
        scores[j] = float('-inf')
    x_max = max(scores)
    L = 0
    acc = [0, 0, 0, 0]
    for j in range(8):
        w = exp_w(scores[j], x_max)   # -inf -> d <= -4 -> 0
        L += w
        for kk in range(4):
            acc[kk] += w * v[j][kk]
    return [round_div(acc[kk], L) for kk in range(4)]


def main():
    N = 100
    cases = []

    # 固定样例（可手算对照）
    q_fixed = [1, 2, 1, 2]
    k_fixed = [[1, 0, 1, 0], [0, 1, 0, 1], [1, 1, 1, 1], [2, 0, 2, 0],
               [0, 2, 0, 2], [-1, 0, -1, 0], [1, 1, 0, 0], [0, 0, 1, 1]]
    v_fixed = [[4, 2, 1, 3], [1, 6, 2, 1], [3, 1, 4, 1], [2, 2, 2, 2],
               [1, 1, 1, 1], [5, 0, 5, 0], [0, 3, 0, 3], [1, 1, 1, 1]]
    cases.append((q_fixed, k_fixed, v_fixed))

    rng = random.Random(0)
    for _ in range(N - 1):
        q = [rng.randint(-128, 127) for _ in range(4)]
        k = [[rng.randint(-128, 127) for _ in range(4)] for _ in range(8)]
        v = [[rng.randint(-128, 127) for _ in range(4)] for _ in range(8)]
        cases.append((q, k, v))

    THRESH = 0
    with open("stim.hex", "w") as fs, open("exp.hex", "w") as fe, \
         open("exp_sel.hex", "w") as fsel, open("exp_causal.hex", "w") as fc:
        for q, k, v in cases:
            for x in q:
                fs.write("%02X\n" % (x & 0xFF))
            for j in range(8):
                for kk in range(4):
                    fs.write("%02X\n" % (k[j][kk] & 0xFF))
            for j in range(8):
                for kk in range(4):
                    fs.write("%02X\n" % (v[j][kk] & 0xFF))
            for x in golden(q, k, v):
                fe.write("%02X\n" % (x & 0xFF))
            mask, cnt = filter_golden(q, k, THRESH)
            fsel.write("%02X\n" % (mask & 0xFF))   # 每 case 2 字节：sel_mask
            fsel.write("%02X\n" % (cnt & 0xFF))     #                 sel_cnt
            for p in range(8):                      # A 加分项：8 个 q_pos × 4 输出
                for x in causal_golden(q, k, v, p):
                    fc.write("%02X\n" % (x & 0xFF))

    print("generated %d cases -> stim.hex, exp.hex, exp_sel.hex, exp_causal.hex" % len(cases))


if __name__ == "__main__":
    main()
