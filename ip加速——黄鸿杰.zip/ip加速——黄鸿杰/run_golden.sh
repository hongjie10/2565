#!/bin/sh
# 编译并运行 golden model，打印参考值
cd "$(dirname "$0")"
iverilog -g2012 -o simv_golden tb/golden_model.v tb/tb_golden.v && vvp simv_golden
