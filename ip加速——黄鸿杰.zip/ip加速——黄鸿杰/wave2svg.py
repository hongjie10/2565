#!/usr/bin/env python3
"""wave2svg.py — 把 wave.vcd 画成一张波形图 wave.svg（gtkwave 打不开时的替代）。

用法：py wave2svg.py
输出：wave.svg（双击用浏览器打开，可截图放进报告）
"""
import re

STATE_NAMES = ["IDLE", "LOAD_Q", "LOAD_KV", "DOT", "MAX", "EXP", "UPDATE", "NORM", "OUTPUT", "DONE"]

# 要画的信号：id -> (显示名, 类型)  类型 bit=1位波形, bus=多位(带数值标签)
SHOW = {
    '!': ('clk',       'bit'),
    'I': ('state',     'state'),
    '&': ('q_valid',   'bit'),
    '$': ('kv_valid',  'bit'),
    ',': ('out_valid', 'bit'),
    '5': ('done',      'bit'),
    '-': ('out_data',  'bus'),
}

def parse_vcd(path):
    """解析 VCD，返回 {id: [(t, value), ...]} 的边沿序列，以及每个信号的宽度。"""
    lines = open(path, encoding="utf-8", errors="replace").read().splitlines()
    ids = {}        # id -> width
    cur = {}        # id -> 当前值
    events = {}     # id -> [(t, value)] 每次变化
    t = 0
    in_def = True
    for ln in lines:
        ln = ln.strip()
        if ln.startswith("$enddefinitions"):
            in_def = False
            continue
        if in_def:
            m = re.match(r"\$var\s+(\S+)\s+(\d+)\s+(\S+)\s+(\S+)", ln)
            if m:
                kind, width, sid, name = m.groups()
                if sid in SHOW:
                    ids[sid] = int(width)
            continue
        if not ln:
            continue
        if ln.startswith("#"):
            t = int(ln[1:])
        elif ln.startswith("b"):
            m = re.match(r"b([01xz]+)\s+(\S+)$", ln)
            if m:
                bits, sid = m.groups()
                if sid not in SHOW:
                    continue
                try:
                    v = int(bits, 2)
                except ValueError:
                    continue
                if sid not in cur or cur[sid] != v:
                    cur[sid] = v
                    events.setdefault(sid, []).append((t, v))
        elif ln and ln[0] in "01xz":
            v = 1 if ln[0] == "1" else 0
            sid = ln[1:]
            if sid not in SHOW:
                continue
            if sid not in cur or cur[sid] != v:
                cur[sid] = v
                events.setdefault(sid, []).append((t, v))
    return ids, events

def ns(t):
    return t / 1000.0   # 1ps -> 1ns

def main():
    ids, events = parse_vcd("wave.vcd")
    t_end = max((ev[-1][0] for ev in events.values() if ev), default=0)

    # 布局参数
    LEFT = 150          # 左边信号名区域宽
    MARGIN = 40         # 右边留白
    ROW_H = 40          # 每行高
    TOP = 60            # 顶部留白（画时间刻度）
    BOTTOM = 30
    W = 1280
    H = TOP + len(SHOW) * ROW_H + BOTTOM
    tmax = ns(t_end) * 1.02

    def x_of(t):
        return LEFT + (ns(t) / tmax) * (W - LEFT - MARGIN)

    parts = []
    parts.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
                 f'viewBox="0 0 {W} {H}" font-family="Consolas, monospace" font-size="13">')
    parts.append(f'<rect x="0" y="0" width="{W}" height="{H}" fill="white"/>')
    parts.append(f'<text x="20" y="28" font-size="16" font-weight="bold" fill="#111">'
                 f'Attention IP 仿真波形 (wave.vcd)</text>')

    # 时间刻度线 + 刻度值
    parts.append(f'<line x1="{LEFT}" y1="{TOP}" x2="{LEFT}" y2="{H-BOTTOM}" stroke="#ccc"/>')
    for tt in range(0, int(tmax) + 1, 200):
        x = x_of(tt * 1000)
        parts.append(f'<line x1="{x:.1f}" y1="{TOP}" x2="{x:.1f}" y2="{H-BOTTOM}" stroke="#eee"/>')
        parts.append(f'<text x="{x:.1f}" y="{TOP-8}" fill="#888" text-anchor="middle" font-size="11">{tt}ns</text>')

    # 逐信号画
    for row, (sid, (name, typ)) in enumerate(SHOW.items()):
        y_hi = TOP + row * ROW_H + 8
        y_lo = TOP + row * ROW_H + ROW_H - 8
        y_mid = (y_hi + y_lo) / 2

        # 信号名
        parts.append(f'<text x="{LEFT-10}" y="{y_mid+4}" fill="#000" text-anchor="end" '
                     f'font-weight="bold">{name}</text>')
        # 行背景
        parts.append(f'<rect x="{LEFT}" y="{TOP+row*ROW_H}" width="{W-LEFT-MARGIN}" height="{ROW_H}" fill="#fafafa"/>')

        ev = events.get(sid, [])
        if not ev:
            continue

        if typ == 'bit':
            # 数字波形：先画高低电平线段，再画跳变竖线
            # 取每个时间段 [ev[i], ev[i+1]] 的电平
            pts = [(0, ev[0][1])] + ev + [(t_end, ev[-1][1])]
            # 合并成段
            segs = []
            for i in range(len(pts) - 1):
                t0, v0 = pts[i]
                t1, v1 = pts[i + 1]
                if v0 == v1:
                    segs.append((t0, t1, v0))
                else:
                    # 跳变发生在 t1
                    segs.append((t0, t1, v0))
            # 画每段电平
            for (t0, t1, v) in segs:
                x0, x1 = x_of(t0), x_of(t1)
                y = y_hi if v == 1 else y_lo
                parts.append(f'<line x1="{x0:.1f}" y1="{y}" x2="{x1:.1f}" y2="{y}" '
                             f'stroke="#06c" stroke-width="1.6"/>')
            # 画跳变竖线
            for (t0, t1, v) in segs:
                x1 = x_of(t1)
                parts.append(f'<line x1="{x1:.1f}" y1="{y_lo}" x2="{x1:.1f}" y2="{y_hi}" '
                             f'stroke="#06c" stroke-width="1.2"/>')
            # 高电平标 1
            for (t0, t1, v) in segs:
                if v == 1 and (x_of(t1) - x_of(t0)) > 20:
                    parts.append(f'<text x="{((x_of(t0)+x_of(t1))/2):.1f}" y="{y_hi-4}" '
                                 f'fill="#06c" text-anchor="middle" font-size="11">1</text>')
        else:
            # 多位信号：画水平中线，段间写数值标签
            pts = [(0, ev[0][1])] + ev + [(t_end, ev[-1][1])]
            for i in range(len(pts) - 1):
                t0, v0 = pts[i]
                t1 = pts[i + 1][0]
                x0, x1 = x_of(t0), x_of(t1)
                parts.append(f'<line x1="{x0:.1f}" y1="{y_mid}" x2="{x1:.1f}" y2="{y_mid}" '
                             f'stroke="#a60" stroke-width="1.6"/>')
                # 标签
                if typ == 'state':
                    label = STATE_NAMES[v0] if 0 <= v0 < len(STATE_NAMES) else f"?(v0)"
                else:
                    sv = v0 - 256 if v0 >= 128 else v0
                    label = str(sv)
                if (x1 - x0) > 14:
                    parts.append(f'<text x="{((x0+x1)/2):.1f}" y="{y_mid+12}" '
                                 f'fill="#a60" text-anchor="middle" font-size="11">{label}</text>')

    parts.append('</svg>')
    open("wave.svg", "w", encoding="utf-8").write("\n".join(parts))
    print("生成完成 -> wave.svg（共 %d 个信号，时间 0 ~ %.0f ns）" % (len(SHOW), tmax))

if __name__ == "__main__":
    main()
