// tb_filter.v — D 加分项独立测试：简单筛选
// 读取 stim.hex（输入）和 exp_sel.hex（每 case 2 字节：sel_mask, sel_cnt），
// 串行驱动 RTL，等 sel_valid 拉高后比对筛选结果。期望由 golden.py 计算。
`timescale 1ns/1ps
module tb_filter;
  localparam N = 100;         // 与 golden.py 的 N 一致
  localparam W = 68;          // 每组 4 Q + 32 K + 32 V 字节

  reg clk, rst_n, start;
  reg signed [7:0] q_in, k_in, v_in;
  reg q_valid, kv_valid;
  reg [2:0] q_pos;   // A 加分项：query 位置，固定 7 = 不屏蔽
  wire data_ready;
  wire signed [7:0] out_data;
  wire out_valid, done;
  wire [7:0] sel_mask;
  wire [3:0] sel_cnt;
  wire sel_valid;

  attention_ip dut(.clk(clk), .rst_n(rst_n), .start(start),
                   .q_in(q_in), .k_in(k_in), .v_in(v_in),
                   .q_valid(q_valid), .kv_valid(kv_valid),
                   .q_pos(q_pos),
                   .data_ready(data_ready), .out_data(out_data),
                   .out_valid(out_valid), .done(done),
                   .sel_mask(sel_mask), .sel_cnt(sel_cnt),
                   .sel_valid(sel_valid));

  reg [7:0] stim    [0:W*N-1];   // 输入字节
  reg [7:0] exp_sel [0:2*N-1];   // 每 case 2 字节：sel_mask, sel_cnt

  integer errors;
  integer t, i;

  always #5 clk = ~clk;        // 10ns 时钟

  // 跑第 c 组：驱动 Q/K/V，等 sel_valid 后比对 sel_mask/sel_cnt
  task run_case(input integer c);
    integer i;
    reg [31:0]  q;
    reg [255:0] k, v;
    begin
      q = 0; k = 0; v = 0;
      for (i = 0; i < 4; i = i + 1) q[i*8 +: 8] = stim[c*W + i];
      for (i = 0; i < 32; i = i + 1) begin
        k[i*8 +: 8] = stim[c*W + 4 + i];
        v[i*8 +: 8] = stim[c*W + 36 + i];
      end

      @(posedge clk); start = 1;
      @(posedge clk); start = 0;

      q_valid = 1;
      for (i = 0; i < 4; i = i + 1) begin
        q_in = q[i*8 +: 8]; @(posedge clk);
      end
      q_valid = 0;

      kv_valid = 1;
      for (i = 0; i < 32; i = i + 1) begin
        k_in = k[i*8 +: 8]; v_in = v[i*8 +: 8]; @(posedge clk);
      end
      kv_valid = 0;

      // 等 sel_valid 拉高（UPDATE 态，sel_mask/sel_cnt 已稳定）
      while (sel_valid !== 1'b1) @(posedge clk);

      if (sel_mask !== exp_sel[c*2 + 0]) begin
        $display("FAIL case %0d sel_mask: rtl=%h exp=%h",
                 c, sel_mask, exp_sel[c*2 + 0]);
        errors = errors + 1;
      end
      if (sel_cnt !== exp_sel[c*2 + 1][3:0]) begin
        $display("FAIL case %0d sel_cnt: rtl=%0d exp=%0d",
                 c, sel_cnt, exp_sel[c*2 + 1][3:0]);
        errors = errors + 1;
      end

      // 等整组跑完，避免下一组 start 与本组冲突
      while (done !== 1'b1) @(posedge clk);
      @(posedge clk);
    end
  endtask

  initial begin
    $dumpfile("wave_filter.vcd");
    $dumpvars(0, dut);
    $readmemh("stim.hex", stim);
    $readmemh("exp_sel.hex", exp_sel);

    clk = 0; rst_n = 0; start = 0;
    q_in = 0; k_in = 0; v_in = 0; q_valid = 0; kv_valid = 0; q_pos = 3'd7;
    errors = 0;

    #3 rst_n = 1;

    for (t = 0; t < N; t = t + 1) run_case(t);

    $display("TOTAL FILTER ERRORS = %0d", errors);
    if (errors == 0) $display("FILTER ALL PASS");
    else             $display("FILTER SOME FAIL");
    $finish;
  end
endmodule
