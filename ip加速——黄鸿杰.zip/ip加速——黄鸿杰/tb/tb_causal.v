// tb_causal.v — A 加分项独立测试：因果 Mask
// 读取 stim.hex（输入）和 exp_causal.hex（每 case 8 个 q_pos × 4 输出），
// 对每个 case 扫 q_pos=0..7，逐项比对输出。期望由 golden.py 计算。
`timescale 1ns/1ps
module tb_causal;
  localparam N = 100;          // 与 golden.py 的 N 一致
  localparam W = 68;           // 每组 4 Q + 32 K + 32 V 字节

  reg clk, rst_n, start;
  reg signed [7:0] q_in, k_in, v_in;
  reg q_valid, kv_valid;
  reg [2:0] q_pos;
  wire data_ready;
  wire signed [7:0] out_data;
  wire out_valid, done;

  attention_ip dut(.clk(clk), .rst_n(rst_n), .start(start),
                   .q_in(q_in), .k_in(k_in), .v_in(v_in),
                   .q_valid(q_valid), .kv_valid(kv_valid),
                   .q_pos(q_pos),
                   .data_ready(data_ready), .out_data(out_data),
                   .out_valid(out_valid), .done(done));

  reg [7:0] stim       [0:W*N-1];    // 输入字节
  reg [7:0] exp_causal [0:32*N-1];   // 每 case 8 q_pos × 4 输出

  integer errors;
  integer t, p, i;

  always #5 clk = ~clk;        // 10ns 时钟

  // 跑第 c 组、q_pos=qp：驱动 Q/K/V，采集输出并与 exp_causal 比对
  task run_case(input integer c, input integer qp);
    integer i;
    reg [31:0]  q;
    reg [255:0] k, v;
    reg signed [7:0] rtl_o [0:3];
    begin
      q = 0; k = 0; v = 0;
      for (i = 0; i < 4; i = i + 1) q[i*8 +: 8] = stim[c*W + i];
      for (i = 0; i < 32; i = i + 1) begin
        k[i*8 +: 8] = stim[c*W + 4 + i];
        v[i*8 +: 8] = stim[c*W + 36 + i];
      end

      @(posedge clk); start = 1; q_pos = qp;
      @(posedge clk); start = 0;

      q_valid = 1;
      for (i = 0; i < 4; i = i + 1) begin
        q_in = q[i*8 +: 8]; @(posedge clk);
      end
      q_valid = 0;

      kv_valid = 1;
      for (i = 0; i < 32; i = i + 1) begin
        k_in = k[i*8 +: 8]; v_in = v[i*8 +: 8]; @(posedge clk);
      end
      kv_valid = 0;

      for (i = 0; i < 4; i = i + 1) begin
        while (out_valid !== 1'b1) @(posedge clk);
        rtl_o[i] = out_data;
        @(posedge clk);
      end
      while (done !== 1'b1) @(posedge clk);
      @(posedge clk);

      for (i = 0; i < 4; i = i + 1) begin
        if (rtl_o[i] !== exp_causal[c*32 + qp*4 + i]) begin
          $display("FAIL case %0d q_pos=%0d O[%0d]: rtl=%0d exp=%0d",
                   c, qp, i, $signed(rtl_o[i]), $signed(exp_causal[c*32 + qp*4 + i]));
          errors = errors + 1;
        end
      end
    end
  endtask

  initial begin
    $dumpfile("wave_causal.vcd");
    $dumpvars(0, dut);
    $readmemh("stim.hex", stim);
    $readmemh("exp_causal.hex", exp_causal);

    clk = 0; rst_n = 0; start = 0;
    q_in = 0; k_in = 0; v_in = 0; q_valid = 0; kv_valid = 0; q_pos = 0;
    errors = 0;

    #3 rst_n = 1;

    for (t = 0; t < N; t = t + 1)
      for (p = 0; p < 8; p = p + 1)
        run_case(t, p);

    $display("TOTAL CAUSAL ERRORS = %0d", errors);
    if (errors == 0) $display("CAUSAL ALL PASS");
    else             $display("CAUSAL SOME FAIL");
    $finish;
  end
endmodule
