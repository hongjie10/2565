// tb_attention.v — 读取 Python 生成的向量(stim.hex)和期望(exp.hex)，
// 串行驱动 RTL，逐项比对。期望由 golden.py 计算。
`timescale 1ns/1ps
module tb_attention;
  localparam N = 100;        // 与 golden.py 的 N 一致
  localparam W = 68;           // 每组 4 Q + 32 K + 32 V 字节

  reg clk, rst_n, start;
  reg signed [7:0] q_in, k_in, v_in;
  reg q_valid, kv_valid;
  reg [2:0] q_pos;   // A 加分项：query 位置，固定 7 = 不屏蔽
  wire data_ready;
  wire signed [7:0] out_data;
  wire out_valid, done;

  attention_ip dut(.clk(clk), .rst_n(rst_n), .start(start),
                   .q_in(q_in), .k_in(k_in), .v_in(v_in),
                   .q_valid(q_valid), .kv_valid(kv_valid),
                   .q_pos(q_pos),
                   .data_ready(data_ready), .out_data(out_data),
                   .out_valid(out_valid), .done(done));

  reg [7:0]  stim [0:W*N-1];   // 输入字节
  reg [7:0] exp  [0:4*N-1];   // 期望输出

  integer errors;
  integer t, i;

  always #5 clk = ~clk;        // 10ns 时钟

  // 跑第 c 组：从 stim 取 Q/K/V，串行送入 RTL，采集输出并与 exp 比对
  task run_case(input integer c);
    integer i;
    reg [31:0]  q;
    reg [255:0] k, v;
    reg signed [7:0] rtl_o [0:3];
    begin
      q = 0; k = 0; v = 0;
      for (i = 0; i < 4; i = i + 1) q[i*8 +: 8] = stim[c*W + i];
      for (i = 0; i < 32; i = i + 1) begin
        k[i*8 +: 8] = stim[c*W + 4 + i];
        v[i*8 +: 8] = stim[c*W + 36 + i];
      end

      @(posedge clk); start = 1;
      @(posedge clk); start = 0;

      q_valid = 1;
      for (i = 0; i < 4; i = i + 1) begin
        q_in = q[i*8 +: 8]; @(posedge clk);
      end
      q_valid = 0;

      kv_valid = 1;
      for (i = 0; i < 32; i = i + 1) begin
        k_in = k[i*8 +: 8]; v_in = v[i*8 +: 8]; @(posedge clk);
      end
      kv_valid = 0;

      for (i = 0; i < 4; i = i + 1) begin
        while (out_valid !== 1'b1) @(posedge clk);
        rtl_o[i] = out_data;
        @(posedge clk);
      end
      while (done !== 1'b1) @(posedge clk);
      @(posedge clk);

      for (i = 0; i < 4; i = i + 1) begin
        if (rtl_o[i] !== exp[c*4 + i]) begin
          $display("FAIL case %0d O[%0d]: rtl=%0d exp=%0d",
                   c, i, $signed(rtl_o[i]), $signed(exp[c*4 + i]));
          errors = errors + 1;
        end
      end
    end
  endtask

  initial begin
    $dumpfile("wave.vcd");
    $dumpvars(0, dut);
    $readmemh("stim.hex", stim);
    $readmemh("exp.hex", exp);

    clk = 0; rst_n = 0; start = 0;
    q_in = 0; k_in = 0; v_in = 0; q_valid = 0; kv_valid = 0; q_pos = 3'd7;
    errors = 0;

    #3 rst_n = 1;

    for (t = 0; t < N; t = t + 1) run_case(t);

    $display("TOTAL ERRORS = %0d", errors);
    if (errors == 0) $display("ALL PASS");
    else             $display("SOME FAIL");
    $finish;
  end
endmodule
