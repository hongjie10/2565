#!/usr/bin/env python3
"""show_wave.py — 把 wave.vcd 的关键信号用文字画出来（gtkwave 打不开时的替代）。

用法：py show_wave.py
输出 state 时间线、输入/输出有效信号脉冲、以及 out_data 的数值。
"""
import re

ST = ["IDLE", "LOAD_Q", "LOAD_KV", "DOT", "MAX", "EXP", "UPDATE", "NORM", "OUTPUT", "DONE"]

# 关注的信号 id -> (名字, 类型)  类型 scalar=1位 / vec=多位
WATCH = {
    'I': ('state',     'vec'),
    '&': ('q_valid',   'scalar'),
    '$': ('kv_valid',  'scalar'),
    ',': ('out_valid', 'scalar'),
    '5': ('done',      'scalar'),
    '-': ('out_data',  'vec'),
    ')': ('start',     'scalar'),
    'C': ('cnt',       'vec'),
}

lines = open("wave.vcd", encoding="utf-8", errors="replace").read().splitlines()

cur = {k: None for k in WATCH}
state_ev = []          # (t_ps, state值)
pulses = {k: [] for k in WATCH}   # (t_ps, 值) 边沿
out_ev = []            # (t_ps, out_data值)

t = 0
started = False
for ln in lines:
    ln = ln.strip()
    if ln.startswith("$enddefinitions"):
        started = True
        continue
    if not started:
        continue
    if ln.startswith("#"):
        t = int(ln[1:])
    elif ln.startswith("b"):
        m = re.match(r"b([01xz]+)\s+(\S+)$", ln)
        if m:
            bits, sid = m.groups()
            if sid not in WATCH:
                continue
            try:
                v = int(bits, 2)
            except ValueError:
                continue
            if cur[sid] != v:
                cur[sid] = v
                if sid == 'I':
                    state_ev.append((t, v))
                elif sid == '-':
                    out_ev.append((t, v))
                else:
                    pulses[sid].append((t, v))
    elif ln and ln[0] in "01xz":
        v = 1 if ln[0] == "1" else 0
        sid = ln[1:]
        if sid not in WATCH:
            continue
        if cur[sid] != v:
            cur[sid] = v
            pulses[sid].append((t, v))

# ---- 打印 ----
def ns(t):
    return t / 1000.0  # 1ps timescale -> ns

print("=== state 状态机时间线（时钟周期 10ns）===")
for tt, v in state_ev:
    name = ST[v] if 0 <= v <= 9 else f"?({v})"
    print(f"  t={ns(tt):8.1f}ns  -> {name}")

print("\n=== 有效信号脉冲（高电平期间）===")
for sid, (name, _) in WATCH.items():
    if name in ("state", "cnt", "out_data"):
        continue
    edges = pulses.get(sid, [])
    hi = None
    for tt, v in edges:
        if v == 1 and hi is None:
            hi = tt
        elif v == 0 and hi is not None:
            cyc = (tt - hi) / 10000
            print(f"  {name:10s} 高: {ns(hi):8.1f}ns ~ {ns(tt):8.1f}ns   ({cyc:.0f} 拍)")
            hi = None
    if hi is not None:
        print(f"  {name:10s} 高: {ns(hi):8.1f}ns ~ 一直到最后")

print("\n=== 输出 out_data（OUTPUT 状态期间，8-bit 有符号）===")
for tt, v in out_ev:
    sv = v - 256 if v >= 128 else v   # 8-bit 补码转有符号
    print(f"  t={ns(tt):8.1f}ns  out_data = {sv}")
