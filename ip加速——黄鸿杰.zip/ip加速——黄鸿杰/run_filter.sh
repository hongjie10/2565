#!/bin/sh
# D 加分项：简单筛选独立测试
# 1) Python 黄金模型生成测试向量与期望输出  2) 编译并运行筛选比对
cd "$(dirname "$0")"

# 定位 Python（winget 装到用户目录，shell 里可能仍是 Store 占位符）
PY=""
for p in "$LOCALAPPDATA"/Programs/Python/Python3*/python.exe; do
  if [ -x "$p" ]; then PY="$p"; break; fi
done
[ -z "$PY" ] && PY=python

"$PY" golden.py || { echo "golden.py 生成失败"; exit 1; }

iverilog -g2012 -o simv_filter \
  rtl/attention_ip.v rtl/divider.v rtl/exp_lut.v \
  tb/tb_filter.v && vvp simv_filter
