// exp_lut.v — 定点指数查找表（可综合）
// weight = round(exp(score - x_max) * 16)，5bit 无符号定点，小数保留 4 位
// 只有 5 个有效值：d>=0→16, -1→6, -2→2, -3→1, <=-4→0（保证 L 最小为 16，不会除 0）
`timescale 1ns/1ps
module exp_lut (
  input  signed [17:0] score,
  input  signed [17:0] x_max,
  output reg  [4:0]    weight
);
  wire signed [17:0] d = score - x_max;
  always @* begin
    if      (d >= 0)  weight = 5'd16;
    else if (d == -1) weight = 5'd6;
    else if (d == -2) weight = 5'd2;
    else if (d == -3) weight = 5'd1;
    else              weight = 5'd0;
  end
endmodule
