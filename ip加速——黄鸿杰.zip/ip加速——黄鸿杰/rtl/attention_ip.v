// attention_ip.v — Attention 加速器顶层（S=8, d=4）
// 两遍缓冲结构：先算 8 个 score 找 x_max，再做稳定 softmax、定点权重、四舍五入归一化
// 数据流：LOAD_Q -> LOAD_KV -> (DOT x8) -> MASK -> MAX -> (EXP x8) -> FILTER -> (UPDATE x8) -> NORM -> OUTPUT -> DONE
`timescale 1ns/1ps
module attention_ip (
  input  clk, rst_n, start,
  input  signed [7:0] q_in, k_in, v_in,
  input  q_valid, kv_valid,
  input  [2:0] q_pos,   // A 加分项：query 位置 i（0..7），屏蔽 j > i 的 key
  output data_ready,
  output signed [7:0] out_data,
  output out_valid, done,
  output reg [7:0] sel_mask,   // D 加分项：选中 key 的掩码（bit j=1 表示 key j 选中）
  output reg [3:0] sel_cnt,    // 选中 key 的个数
  output       sel_valid       // sel_mask/sel_cnt 有效（UPDATE 态为高）
);

  // ---- 状态 ----
  localparam IDLE=0, LOAD_Q=1, LOAD_KV=2, DOT=3, MASK=4, MAX=5, EXP=6,
             FILTER=7, UPDATE=8, NORM=9, OUTPUT=10, DONE=11;
  reg [3:0] state;

  // ---- D 加分项：简单筛选阈值（weight > THRESH 的 key 被选中）----
  parameter [4:0] THRESH = 5'd0;
  // ---- A 加分项：因果 Mask 用的负无穷 ----
  // 不能用 18bit 真正最小值 -131072：score - x_max 会下溢回正，被屏蔽 key 反而 weight=16。
  // -65536 比所有真实 score（最小 -65024）都小，且减 x_max（最大 +65536）刚好不溢出。
  localparam signed [17:0] NEG_INF = -18'sd65536;

  // ---- 存储 ----
  reg signed [7:0]  q_reg [0:3];
  reg signed [7:0]  k_buf [0:31];
  reg signed [7:0]  v_buf [0:31];
  reg signed [17:0] score_buf [0:7];   // 8 个 score
  reg signed [17:0] x_max;             // 最大值
  reg [4:0]         weight_buf [0:7];  // 8 个 weight（5bit 定点）
  reg signed [17:0] score;             // DOT 累加器（当前 score）
  reg [7:0]         L;                 // 权重和
  reg signed [15:0] acc [0:3];         // 4 路 ACC
  reg signed [7:0]  o_reg [0:3];       // 输出

  // ---- 计数 ----
  reg [4:0] cnt;   // 0..31
  reg [2:0] j;     // token 0..7

  // ---- 除法器 ----
  reg        div_start;
  reg signed [15:0] div_dividend;
  reg        norm_wait;
  wire signed [7:0] div_quotient;
  wire       div_done;
  divider u_div(.clk(clk), .rst_n(rst_n), .start(div_start),
                .dividend(div_dividend), .divisor(L),
                .quotient(div_quotient), .done(div_done));

  // ---- exp_lut ----
  wire signed [17:0] score_j = score_buf[j];
  wire [4:0] lut_weight;
  exp_lut u_lut(.score(score_j), .x_max(x_max), .weight(lut_weight));

  // ---- 组合逻辑找最大值 ----
  wire signed [17:0] mx01 = (score_buf[0] > score_buf[1]) ? score_buf[0] : score_buf[1];
  wire signed [17:0] mx23 = (score_buf[2] > score_buf[3]) ? score_buf[2] : score_buf[3];
  wire signed [17:0] mx45 = (score_buf[4] > score_buf[5]) ? score_buf[4] : score_buf[5];
  wire signed [17:0] mx67 = (score_buf[6] > score_buf[7]) ? score_buf[6] : score_buf[7];
  wire signed [17:0] mx0123 = (mx01 > mx23) ? mx01 : mx23;
  wire signed [17:0] mx4567 = (mx45 > mx67) ? mx45 : mx67;
  wire signed [17:0] score_max = (mx0123 > mx4567) ? mx0123 : mx4567;

  integer i;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state <= IDLE; cnt <= 0; j <= 0;
      score <= 0; x_max <= 0; L <= 0;
      div_start <= 0; norm_wait <= 0;
      for (i = 0; i < 4; i = i + 1) begin
        q_reg[i] <= 0; acc[i] <= 0; o_reg[i] <= 0;
      end
      for (i = 0; i < 32; i = i + 1) begin
        k_buf[i] <= 0; v_buf[i] <= 0;
      end
      for (i = 0; i < 8; i = i + 1) begin
        score_buf[i] <= 0; weight_buf[i] <= 0;
      end
      sel_mask <= 8'd0; sel_cnt <= 4'd0;
    end else begin
      div_start <= 0;   // 默认单拍脉冲
      case (state)

        IDLE: if (start) begin state <= LOAD_Q; cnt <= 0; end

        LOAD_Q: if (q_valid) begin
          q_reg[cnt] <= q_in;
          if (cnt == 3) begin state <= LOAD_KV; cnt <= 0; end
          else          cnt <= cnt + 1'b1;
        end

        LOAD_KV: if (kv_valid) begin
          k_buf[cnt] <= k_in;
          v_buf[cnt] <= v_in;
          if (cnt == 31) begin state <= DOT; cnt <= 0; j <= 0; score <= 0; end
          else           cnt <= cnt + 1'b1;
        end

        DOT: begin
          if (cnt == 3) begin
            // 4 项乘加完成，score 是前 3 项之和，再补第 4 项就是完整点积
            score_buf[j] <= score + q_reg[cnt] * k_buf[j*4 + cnt];
            if (j == 7) begin state <= MASK; j <= 0; end
            else        begin j <= j + 1'b1; score <= 0; end
            cnt <= 0;
          end else begin
            score <= score + q_reg[cnt] * k_buf[j*4 + cnt];
            cnt <= cnt + 1'b1;
          end
        end

        MASK: begin
          // A 加分项：因果 Mask，屏蔽 j > q_pos 的 future key（置负无穷，不参与 max）
          for (i = 0; i < 8; i = i + 1)
            if (i > q_pos) score_buf[i] <= NEG_INF;
          state <= MAX;
        end

        MAX: begin
          x_max <= score_max;   // 组合逻辑一次比出最大（future key 已置负无穷）
          state <= EXP; j <= 0;
        end

        EXP: begin
          weight_buf[j] <= lut_weight;   // exp(score_buf[j] - x_max) 定点查表
          if (j == 7) state <= FILTER;
          else        j <= j + 1'b1;
        end

        FILTER: begin
          // D 加分项：weight > THRESH 的 key 选中，输出索引掩码（bit j 对应 key j）
          for (i = 0; i < 8; i = i + 1)
            sel_mask[i] <= (weight_buf[i] > THRESH);
          sel_cnt <= ((weight_buf[0] > THRESH) ? 4'd1 : 4'd0)
                   + ((weight_buf[1] > THRESH) ? 4'd1 : 4'd0)
                   + ((weight_buf[2] > THRESH) ? 4'd1 : 4'd0)
                   + ((weight_buf[3] > THRESH) ? 4'd1 : 4'd0)
                   + ((weight_buf[4] > THRESH) ? 4'd1 : 4'd0)
                   + ((weight_buf[5] > THRESH) ? 4'd1 : 4'd0)
                   + ((weight_buf[6] > THRESH) ? 4'd1 : 4'd0)
                   + ((weight_buf[7] > THRESH) ? 4'd1 : 4'd0);
          // 进入 UPDATE 前的清零（原在 EXP 中完成）
          state <= UPDATE; j <= 0; cnt <= 0; L <= 0;
          acc[0] <= 0; acc[1] <= 0; acc[2] <= 0; acc[3] <= 0;
        end

        UPDATE: begin
          acc[cnt] <= acc[cnt] + weight_buf[j] * v_buf[j*4 + cnt];
          if (cnt == 0) L <= L + weight_buf[j];   // 每个 token 只加一次 L
          if (cnt == 3) begin
            if (j == 7) state <= NORM;
            else        j <= j + 1'b1;
            cnt <= 0;
          end else cnt <= cnt + 1'b1;
        end

        NORM: if (!norm_wait) begin
          // 发起第 cnt 次除法（L>=16，不会除 0）
          div_start <= 1'b1;
          div_dividend <= acc[cnt];
          norm_wait <= 1'b1;
        end else if (div_done) begin
          o_reg[cnt] <= div_quotient;
          norm_wait <= 0;
          if (cnt == 3) begin state <= OUTPUT; cnt <= 0; end
          else          cnt <= cnt + 1'b1;
        end

        OUTPUT: if (cnt == 3) state <= DONE;
                else          cnt <= cnt + 1'b1;

        DONE: state <= IDLE;

        default: state <= IDLE;
      endcase
    end
  end

  // ---- 组合输出 ----
  assign data_ready = (state == LOAD_Q) || (state == LOAD_KV);
  assign out_valid  = (state == OUTPUT);
  assign done       = (state == DONE);
  assign out_data   = (state == OUTPUT) ? o_reg[cnt] : 8'sd0;
  // D 加分项：sel_mask/sel_cnt 在 FILTER 打一拍，从 UPDATE 态起保持稳定
  assign sel_valid  = (state == UPDATE);

endmodule
