// divider.v — 串行恢复余数除法器（可综合）
// dividend: 16-bit 有符号（ACC）；divisor: 8-bit 无符号（L，>0）
// 结果四舍五入（远离零）：先算 |dividend|/divisor 的绝对值商，余数×2>=除数则商+1，再按符号还原
// 共 N=16 次迭代（num 是 16-bit，逐位移入）
`timescale 1ns/1ps
module divider (
  input  clk, rst_n, start,
  input  signed [15:0] dividend,
  input  [7:0]         divisor,
  output reg signed [7:0] quotient,
  output reg done
);
  localparam N = 16;
  reg neg;              // 结果符号
  reg [15:0] num;       // |dividend|
  reg [15:0] rem;       // 余数
  reg [15:0] q;         // 商绝对值
  reg [4:0]  cnt;       // 0..N
  reg busy;             // 正在除：空闲时不做任何事，避免复位后空转

  // 移位 + 试减（组合逻辑，每个周期做一次）
  wire [16:0] shifted  = {rem, num[15]};
  wire        ge       = shifted >= {9'b0, divisor};
  wire [16:0] rem_next = ge ? (shifted - {9'b0, divisor}) : shifted;
  wire [15:0] q_next   = ge ? {q[14:0], 1'b1} : {q[14:0], 1'b0};
  // 四舍五入：{rem,1'b0} = rem*2，若 2*rem >= divisor 则商 +1
  wire round_up = ({rem, 1'b0} >= {9'b0, divisor});

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      quotient <= 0; done <= 0; busy <= 0;
      neg <= 0; num <= 0; rem <= 0; q <= 0; cnt <= 0;
    end else begin
      done <= 0;
      if (start) begin
        busy <= 1'b1;
        neg <= dividend[15];
        num <= dividend[15] ? (~dividend + 1'b1) : dividend;
        rem <= 0; q <= 0; cnt <= 0;
      end else if (busy) begin
        if (cnt < N) begin
          rem <= rem_next[15:0];
          q   <= q_next;
          num <= {num[14:0], 1'b0};
          cnt <= cnt + 1'b1;
        end else begin
          quotient <= neg ? (~(q + round_up) + 1'b1) : (q + round_up);
          done <= 1'b1;
          busy <= 1'b0;
        end
      end
    end
  end
endmodule
