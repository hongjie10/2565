# Attention 加速器 RTL IP 设计（S=8, d=4）

从公式到 RTL，实现一个基础 Attention 加速器 IP，并附带两个加分项（简单筛选、因果 Mask）。

- **固定规格**：Batch=Head=1，序列长 S=8，头维度 d=4；Q[1,4]、K[8,4]、V[8,4]、O[1,4]，全部 8-bit 有符号
- **工具**：Icarus Verilog（iverilog + vvp）、GTKWave、Python 3（黄金模型）

## 核心公式（数值稳定 softmax）

```
1. score_j = Σ_k Q[k]·K_j[k]          # 点积，d=4
2. x_max  = max(score_0..7)           # 先找最大，防 exp 溢出
3. weight_j = round(exp(score_j − x_max) × 16)
4. L = Σ weight_j
5. ACC = Σ weight_j · V_j             # 4 路
6. O = round(ACC / L)                 # 四舍五入远离零
```

减 x_max 不改变 softmax 结果（分子分母同除 exp(x_max)），但保证最大 weight 恒为 16，**永不溢出、永不除 0**（L ≥ 16）。

## 定点化与位宽

| 信号 | 位宽 | 范围（怎么来的） |
|---|---|---|
| score | 18-bit 有符号 | 4 项 8×8 点积，[−65024, 65536] |
| x_max | 18-bit 有符号 | 同 score |
| weight | 5-bit 无符号 | 取值 0/1/2/6/16 |
| L | 8-bit 无符号 | 8 个 weight 相加，[16, 128] |
| ACC | 16-bit 有符号 | 8 项 weight×V，[−16384, 16256] |
| O | 8-bit 有符号 | V 的加权平均，[−128, 127] |

## exp 查找表（weight = round(exp(d)×16)，d = score − x_max）

| d | ≥0 | −1 | −2 | −3 | ≤−4 |
|---|---|---|---|---|---|
| weight | 16 | 6 | 2 | 1 | 0 |

## 数据流与状态机（12 状态，约 200 拍/组）

```
IDLE → LOAD_Q → LOAD_KV → DOT → MASK → MAX → EXP → FILTER → UPDATE → NORM → OUTPUT → DONE
```

| 状态 | 拍数 | 说明 |
|---|---|---|
| LOAD_Q | 4 | 串行载入 Q |
| LOAD_KV | 32 | 串行载入 K、V |
| DOT | 32 | 第一遍：算 8 个 score |
| MASK | 1 | (A) 因果屏蔽，future key 置负无穷 |
| MAX | 1 | 组合树找 x_max |
| EXP | 8 | 第二遍：查表得 8 个 weight |
| FILTER | 1 | (D) 生成 sel_mask |
| UPDATE | 32 | 累加 ACC、L |
| NORM | ~80 | 4 次串行除法 |
| OUTPUT | 4 | 输出 4 个 O |
| DONE | 1 | 回到 IDLE |

两遍缓冲：第一遍（DOT+MAX）先算 score 找 x_max，第二遍（EXP+UPDATE）回头算 weight 并累加——因为 weight 依赖 x_max，而 x_max 依赖全部 score。

## 模块结构

| 模块 | 作用 |
|---|---|
| rtl/attention_ip.v | 顶层 FSM + 存储 + 数据通路 |
| rtl/divider.v | 串行恢复余数除法器（N=16 拍，四舍五入远离零） |
| rtl/exp_lut.v | 定点 exp 查找表（5 值，组合逻辑） |

## 接口信号

| 信号 | 方向 | 说明 |
|---|---|---|
| clk / rst_n | in | 时钟 / 低有效复位 |
| start | in | 启动一组计算 |
| q_in / k_in / v_in | in | 串行数据（8-bit） |
| q_valid / kv_valid | in | 数据有效标志 |
| data_ready | out | 可接收 Q / KV |
| out_data / out_valid | out | 输出 O |
| done | out | 整组完成 |
| q_pos | in | (A) query 位置，屏蔽 j > q_pos |
| sel_mask / sel_cnt / sel_valid | out | (D) 筛选结果 |

## 加分项

### D 简单筛选（稀疏 Attention 扩展）
softmax 后多数 weight≈0，挑出 `weight > THRESH`（默认 0）的 key，输出其索引掩码 `sel_mask` 和个数 `sel_cnt`。阈值作用在 weight 上、weight 又相对 x_max，故为**动态阈值**。复用已算好的 weight_buf，仅加 8 个比较器，1 拍完成。

### A 因果 Mask（自回归屏蔽）
加输入 `q_pos`，把 `j > q_pos` 的 future key 的 score 置负无穷，使其不参与 max、weight 归 0。关键点：**必须在求 x_max 之前屏蔽**；负无穷用 `-65536` 而非 18-bit 最小值 `-131072`（后者 `score−x_max` 会下溢回正）。

## 文件结构

```
rtl/attention_ip.v   顶层 FSM + 数据通路（含 MASK、FILTER）
rtl/divider.v        串行除法器
rtl/exp_lut.v        指数查找表
golden.py            Python 黄金模型：生成测试向量 + 期望输出
tb/tb_attention.v    基础功能独立测试（100 组）
tb/tb_filter.v       D 简单筛选独立测试（100 组）
tb/tb_causal.v       A 因果 Mask 独立测试（100×8 组）
```

## 运行

```bash
py golden.py           # 1. 生成测试向量 stim.hex / exp*.hex
bash run_sim.sh        # 2. 基础功能仿真（RTL vs 期望，逐字节比对）
bash run_filter.sh     # 3. D 简单筛选仿真
bash run_causal.sh     # 4. A 因果 Mask 仿真
```

三个 testbench 最后均打印 `ALL PASS`（0 错误）即验证通过。

## 验证方法（黄金模型比对）

用 Python 独立复刻同一套定点公式（golden.py），生成输入 `stim.hex` 与期望输出 `exp*.hex`；testbench 用 `$readmemh` 读入，串行驱动 RTL，逐字节比对输出。两者独立实现、逐位精确相等，故一致即正确。测试含 1 个可手算的固定样例 + 99 个随机样例，对应验收的"公开样例 + 隐藏随机样例"。
